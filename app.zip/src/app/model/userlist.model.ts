export class Data{
    id:number;
    name:string;
    age:string;
    place:string;
}