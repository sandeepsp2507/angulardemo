import { Component, OnInit } from '@angular/core';
import { Data } from '../model/userlist.model';
import { Router } from "@angular/router";
import { UserService } from '../user.service';

@Component({
  selector: 'app-listusers',
  templateUrl: './listusers.component.html',
  styleUrls: ['./listusers.component.css']
})
export class ListusersComponent implements OnInit {
  users: Data[];
  constructor(private uService: UserService, private router: Router) { }

  ngOnInit() {
    this.uService.getUsers()  
      .subscribe((data: Data[]) => {  
        this.users = data;  
      });
  }

  deleteUser(user: Data): void {  
    this.uService.deleteUser(user.id)  
      .subscribe(data => {  
        this.users = this.users.filter(u => u !== user);  
      })  
  }  

  editUser(user: Data): void {  
    localStorage.removeItem('editUserId');  
    localStorage.setItem('editUserId', JSON.stringify(user)); 
    this.router.navigate(['edit-user',user.id]);  
  }

}
