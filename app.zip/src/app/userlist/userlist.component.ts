import { Component, OnInit } from '@angular/core';
import { ulist } from './userlist';
import { userService } from './userlist.service';

@Component({
  selector: 'app-userlist',
  templateUrl: './userlist.component.html',
  styleUrls: ['./userlist.component.css']
})
export class UserlistComponent implements OnInit {
  userlist:ulist[]=[];
  searchedUser:ulist[]=[];
  errorMessage:string;
  _userSearch:string;

  constructor(private uservice:userService) { }

  ngOnInit():void {
    this.uservice.getuserlist().subscribe(
      userlist =>{
      this.userlist = userlist;
      console.log(this.userlist);

    },
    error =>this.errorMessage = error
      );
  }

  get userSearch():string{
    return this._userSearch;
  }
  
  set userSearch(value:string)
  {
    this._userSearch = value;
    this.searchedUser = this.userSearch ? this.searchUser(this.userSearch):this.userlist;
  }
  
  searchUser(search:string):ulist[]{
  
    search = search.toLocaleLowerCase();
     return this.userlist.filter((userlist:ulist)=>
     userlist.name.toLocaleLowerCase()== search);
    
  }

}
