import { Injectable } from "@angular/core";
import { ulist } from "./userlist";
import { Observable, throwError } from 'rxjs';
import { HttpClient,HttpErrorResponse } from '@angular/common/http';
import {tap, catchError} from 'rxjs/operators';
// import userlist from './../data/userlist.json';

@Injectable({
    providedIn:'root'
    
    })
    
    export class userService{
        userurl = './assets/data/userlist.json';
    
        constructor(private httpSer:HttpClient) {
            //onsole.log(userlist)
        }
    
    
        getuserlist():Observable<any[]>{
        
            return this.httpSer.get<any[]>(this.userurl).pipe(
            tap(data => console.log('userlist : '+JSON.stringify(data)),
            error => {
                console.log(error);
            }
            ),
            catchError(this.handleError)
        );
        }
    
        private handleError(err:HttpErrorResponse){
            let errorMessage = '';
            if (err.error instanceof ErrorEvent) {
              errorMessage = `An error occurred: ${err.error.message}`;
            } else {
              errorMessage = `Server returned code: ${err.status}, error message is: ${err.message}`;
            }
            
            return throwError(errorMessage);
           
        }
    
    }