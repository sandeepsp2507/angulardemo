import { Component, OnInit } from '@angular/core';
import { Data } from '../model/userlist.model';
import { FormBuilder, FormGroup, Validators , ReactiveFormsModule  } from "@angular/forms";
import { Router } from "@angular/router"; 
import { UserService } from '../user.service';

@Component({
  selector: 'app-edituser',
  templateUrl: './edituser.component.html',
  styleUrls: ['./edituser.component.css']
})
export class EdituserComponent implements OnInit {

  empformlabel: string = 'Add User';  
  empformbtn: string = 'Save';
  user:Data

  constructor(private formBuilder: FormBuilder, private router: Router, private empService: UserService) {
    this.user = JSON.parse(localStorage.getItem('editUserId'))
    console.log(this.user )
  }
  addForm: FormGroup;  
  btnvisibility: boolean = true;

  ngOnInit() {
    this.addForm = this.formBuilder.group({  
      id: [this.user.id],  
      name: [this.user.name, Validators.required],
      age: ['', [Validators.required, Validators.maxLength(3)]] ,
      place: ['', Validators.required],
    });  
  
    let userid = localStorage.getItem('editUserId');  
    if (+userid > 0) {  
      this.empService.getUserById(+userid).subscribe(data => {  
        this.addForm.patchValue(data);  
      })
      this.btnvisibility = false;  
      this.empformlabel = 'Edit User';  
      this.empformbtn = 'Update';  
    }
  }

  onSubmit() {  
    console.log('Create fire');  
    this.empService.createUser(this.addForm.value)  
      .subscribe(data => {  
        this.router.navigate(['list-user']);  
      },  
      error => {  
        alert(error);  
      });  
  }  
  onUpdate() {  
    console.log('Update fire');  
    this.empService.updateUser(this.addForm.value).subscribe(data => {  
      this.router.navigate(['list-user']);  
    },  
      error => {  
        alert(error);  
      });  
  }

}
