import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreateusersComponent } from './createusers/createusers.component';
import { EdituserComponent } from './edituser/edituser.component';
import { ListusersComponent } from './listusers/listusers.component';


const routes: Routes = [
  {path:'edit-user/:id',component:EdituserComponent},
  {path:'add-user',component:CreateusersComponent},
  {path:'',component:ListusersComponent, pathMatch: 'full'},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
