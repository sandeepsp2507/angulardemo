import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Data } from "./model/userlist.model";

@Injectable({  
    providedIn: 'root'  
  })  
  export class UserService {  
    
    constructor(private http: HttpClient) { }  
    baseUrl: string = 'http://localhost:3000/Data/';  
    
    getUsers() {  
      return this.http.get<Data[]>(this.baseUrl);  
    }  
    deleteUser(id: number) {  
      return this.http.delete<Data[]>(this.baseUrl + id);  
    }  
    createUser(user: Data) {  
      return this.http.post(this.baseUrl, user);  
    }  
    getUserById(id: number) {  
      return this.http.get<Data>(this.baseUrl + '/' + id);  
    }  
    updateUser(user: Data) {  
      return this.http.put(this.baseUrl + '/' + user.id, user);  
    }  
  } 