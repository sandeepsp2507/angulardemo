import { Component, OnInit } from '@angular/core';
import { Data } from '../model/userlist.model';
import { FormBuilder, FormGroup, Validators , ReactiveFormsModule  } from "@angular/forms";
import { Router } from "@angular/router"; 
import { UserService } from '../user.service';

@Component({
  selector: 'app-createusers',
  templateUrl: './createusers.component.html',
  styleUrls: ['./createusers.component.css']
})
export class CreateusersComponent implements OnInit {
  empformlabel: string = 'Add User';  
  empformbtn: string = 'Save';

  constructor(private formBuilder: FormBuilder, private router: Router, private empService: UserService) { }
  addForm: FormGroup;  
  btnvisibility: boolean = true;

  ngOnInit() {
    this.addForm = this.formBuilder.group({  
      id: [],  
      user_name: ['tyyyyy', Validators.required],
      user_age: ['', [Validators.required, Validators.maxLength(3)]] ,
      user_place: ['', Validators.required],
    });  
  
    let userid = localStorage.getItem('editUserId');  
    if (+userid > 0) {  
      this.empService.getUserById(+userid).subscribe(data => {  
        this.addForm.patchValue(data);  
      })
      this.btnvisibility = false;  
      this.empformlabel = 'Edit User';  
      this.empformbtn = 'Update';  
    } 
  }

  onSubmit() {  
    console.log('Create fire');  
    this.empService.createUser(this.addForm.value)  
      .subscribe(data => {  
        this.router.navigate(['list-emp']);  
      },  
      error => {  
        alert(error);  
      });  
  }  
  onUpdate() {  
    console.log('Update fire');  
    this.empService.updateUser(this.addForm.value).subscribe(data => {  
      this.router.navigate(['list-emp']);  
    },  
      error => {  
        alert(error);  
      });  
  }

}
