export interface ulist{
      id:number;
      name:string;
      age:string;
      place:string;
  }